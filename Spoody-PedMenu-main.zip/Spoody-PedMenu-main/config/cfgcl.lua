ConfigCL = {}

ConfigCL.OpenMenu = 170 -- Key to Open Menu, feel free to change this.
ConfigCL.QOne = '~r~Spawn Ped By Name' -- Number One Title
ConfigCL.WTwo = 'Officer Habibi' -- Number Two Title
ConfigCL.EThree = 'Vato 1' -- Number Three Title
ConfigCL.RFour = 'Johnny Orlandus' -- Number Three Title
ConfigCL.TFive = 'Spaceman' -- Number Three Title
ConfigCL.YSix = 'Alien' -- Number Three Title


--Please DO NOT touch any of these values, if you do the menu will break.
-------------------------------------------------------------------------
ConfigCL.PressE = 103

ConfigCL.Index = -1
ConfigCL.IndexTwo = 1
ConfigCL.IndexThree = 0.0001
ConfigCL.IndexFour = 1000
ConfigCL.IndexFive = 0.4

ConfigCL.Zero = 0
ConfigCL.End = 128
ConfigCL.ZeroTwo = 0.0
ConfigCL.OneTwo = 1.0
ConfigCL.Fifty = 50

ConfigCL.DrawInfoOne = 0.015
ConfigCL.DrawInfoTwo = 0.71

ConfigCL.One = 0.45
ConfigCL.Two = 0.005
ConfigCL.Three = 255
ConfigCL.Four = 4
ConfigCL.Pause = 5

ConfigCL.Five = 32
ConfigCL.Six = 269
ConfigCL.Seven = 22
ConfigCL.Eight = 36
ConfigCL.Nine = 8
ConfigCL.Ten = 0.40
ConfigCL.Eleven = 7
ConfigCL.Twelve = 186
ConfigCL.Thirteen = 0.378
ConfigCL.Fourteen =205
-------------------------------------------------------------------------
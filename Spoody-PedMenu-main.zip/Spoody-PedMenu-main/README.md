# Spoody-PedMenu
A Standalone Ped-Menu for any types of server based on WarMenu, Runs at about 0.03 / 0.04 MS, Ped Names for the menu can be configurable in the Config file, and the ped hashes (the peds you spawn in) can be configured in the amcl.lua file, Join my discord for support or bug reports! https://discord.gg/mwkNnVEvZF


ADD THIS OR YOUR PED MENU WONT WORK!

insert into Server.CFG!!!!

####Ped Menu!####
add_principal identifier.steam: group.spoodymenu  #
add_principal identifier.steam: group.spoodymenu  #
add_principal identifier.steam: group.spoodymenu  #
add_principal identifier.steam: group.spoodymenu  #
add_principal identifier.steam: group.spoodymenu  #
add_principal identifier.steam: group.spoodymenu  #
add_principal identifier.steam: group.spoodymenu  #


####NO TOUCH! SLAP####
add_ace group.spoodymenu spoodymenu.openmenu allow

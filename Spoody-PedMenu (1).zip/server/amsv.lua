RegisterServerEvent("spoodymenu:openmenucheck")
AddEventHandler("spoodymenu:openmenucheck", function()
    if IsPlayerAceAllowed(source, "spoodymenu.openmenu") then
        TriggerClientEvent("spoodymenu:openmenu", source, true)
    else
        TriggerClientEvent("spoodymenu:openmenu", source, false)
    end
end)
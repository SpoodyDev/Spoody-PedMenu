fx_version 'adamant'
game 'gta5'

client_script {
  'client/amcl.lua',
  'config/cfgcl.lua',
  'client/WarMenu.lua'
}

server_script {
  'server/amsv.lua',
}

ui_page {
  'html/ui.html',
}

files {
  'html/ui.html',
  'html/js/app.js', 
  'html/css/style.css',
}

